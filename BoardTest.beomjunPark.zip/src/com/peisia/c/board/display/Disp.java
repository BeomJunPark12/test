package com.peisia.c.board.display;

import com.beom.board.*;
import com.peisia.util.Cw;

public class Disp {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(15);
		Cw.w(Board.TITLE);
		Cw.space(15);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
	public static void menuMain() {
		Cw.dot();
		Cw.w("[1.글 리스트/2.글 읽기/3.글 쓰기/4.글 삭제/5.글 수정/x.종료]");
		Cw.dot();
		Cw.wn();
	}

}
