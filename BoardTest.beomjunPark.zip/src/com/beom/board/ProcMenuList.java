package com.beom.board;

import com.beom.board.data.Data;
import com.beom.board.data.Post;

public class ProcMenuList {
	static void run() {
		System.out.println("리스트임");
		for(Post p: Data.posts) {
			p.infoForList();
		}
	}
}
