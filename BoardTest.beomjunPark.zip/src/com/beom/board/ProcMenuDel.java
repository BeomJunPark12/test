package com.beom.board;

import com.beom.board.data.Data;
import com.peisia.util.Ci;

public class ProcMenuDel {
	static void run() {
		System.out.println("글 삭제");
		String cmd = Ci.r("삭제할 글 번호");
		int tempSearchIndex = 0;
		
		// 1. 삭제할 글 찾기
		for(int i=0; i<Data.posts.size(); i++) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex = i;
			}
		}
		// 2. 삭제하기
		Data.posts.remove(tempSearchIndex);
		System.out.println("글 수: " + Data.posts.size());
		
		
	}
}
