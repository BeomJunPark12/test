package com.beom.board;

import com.beom.board.data.Data;
import com.beom.board.data.Post;
import com.peisia.util.Ci;

public class ProcMenuUpdate {
	static void run() {
		System.out.println("글 수정하기");
		String cmd = Ci.r("수정할 글 번호");
		
		for(Post p: Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				String content = Ci.rl("수정할 글 내용");
				p.content = content;
				System.out.println("글이 수정되었습니다.");
			}
		}
	}
}
