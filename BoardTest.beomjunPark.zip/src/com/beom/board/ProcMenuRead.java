package com.beom.board;

import com.beom.board.data.Data;
import com.beom.board.data.Post;
import com.peisia.util.Ci;

public class ProcMenuRead {
	static void run() {
		System.out.println("읽기");
		String cmd = Ci.r("읽을 글 번호");
		for(Post p: Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
			}
		}
	}
}
