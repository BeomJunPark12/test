package com.beom.board;

import com.peisia.c.board.display.Disp;
import com.peisia.util.Ci;

public class ProcMenu {
	static void run() {
		Disp.menuMain();
		loop: while (true) {
			String cmd = Ci.r("명령");
			switch (cmd) {
			case "1":		// 리스트
				ProcMenuList.run();
				break;
			case "2":		// 읽기
				ProcMenuRead.run();
				break;
			case "3":
				ProcMenuWrite.run();
				break;
			case "4":
				ProcMenuDel.run();
				break;
			case "5":
				ProcMenuUpdate.run();
				break;
			case "x":
				System.out.println("프로그램 종료");
				break loop;
			default:
				System.out.println("장난 ㄴㄴ");
				break;

			}
		}
	}
}
