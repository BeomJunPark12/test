package com.beom.board.data;

import java.time.LocalDate;

public class Post {
	public static int no = 0;
	public int instanceNo = 0;
	public String title;
	public String content;
	public String writer;
	public String date;
	
	public Post(String title, String content, String writer, String date) {
		no += 1;
		instanceNo += no;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.date = date;
		
		LocalDate now = LocalDate.now();
		date = now.toString();
	}
	public void infoForList() {
		System.out.print("글 번호: "+ instanceNo +"/");
		System.out.print(" 글 제목: "+ title + "/");
		System.out.print(" 작성자: "+ writer + "/");
		System.out.println(" 작성일: "+ date);
	}
	public void infoForRead() {
		System.out.print("글 제목: "+ title +"/");
		System.out.print(" 작성자: "+ writer +"/");
		System.out.print(" 작성일: " + date +"/");
		System.out.println(" 글 내용: "+ content);
	}
}
