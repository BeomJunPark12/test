package com.beom.board.data;

import java.util.ArrayList;

public class Data {
	public static ArrayList<Post> posts;
	public static void loadData() {
		posts = new ArrayList<>();
	}
}
