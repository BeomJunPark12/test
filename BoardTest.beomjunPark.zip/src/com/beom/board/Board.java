package com.beom.board;

import com.beom.board.data.Data;
import com.peisia.c.board.display.Disp;

public class Board {
	public static final String VERSION = "0.0.0";
	public static final String TITLE = "게시판 (" + VERSION + ") feat. beom";
	
	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}
}
