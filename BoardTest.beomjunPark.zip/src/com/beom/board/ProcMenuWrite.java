package com.beom.board;

import com.beom.board.data.Data;
import com.beom.board.data.Post;
import com.peisia.util.Ci;

public class ProcMenuWrite {
	static void run() {
		System.out.println("쓰기");
		
		String title;
		while(true) {
			title = Ci.rl("글제목");
			if(title.length() > 0) {
				break;
			} else {
				System.out.println("장난 ㄴㄴ");
			}
		}
		
		String content;
		while(true) {
			content = Ci.rl("글내용");
			if(content.length() > 0) {
				break;
			} else {
				System.out.println("장난 ㄴㄴ");
			}
		}
		
		String writer;
		while(true) {
			writer = Ci.rl("작성자");
			if(writer.length() > 0) {
				break;
			} else {
				System.out.println("장난 ㄴㄴ");
			}
		}
		
		Post p = new Post(title, content, writer, writer);
		Data.posts.add(p);
		System.out.println("글이 작성되었습니다.");
	}
}
