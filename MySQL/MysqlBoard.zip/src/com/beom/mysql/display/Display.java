package com.beom.mysql.display;

public class Display {
	
	public static void mainMenu() {
		System.out.println("[1] 글리스트 [2] 글읽기 [3] 글쓰기 [4] 글삭제 [e] 프로그램 종료");
	}
	
	public static void bar() {
		System.out.println("====================================================================");
	}
}
