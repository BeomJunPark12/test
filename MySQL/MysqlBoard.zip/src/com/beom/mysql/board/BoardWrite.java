package com.beom.mysql.board;

import java.sql.SQLException;

import com.beom.mysql.util.Ci;
import com.beom.mysql.util.Db;



public class BoardWrite {

	public static void run() {
		String title = Ci.rl("제목을 입력해주세요.");
		String text = Ci.rl("내용을 입력해주세요.");
		String id = Ci.rl("아이디를 입력해주세요.");
		String sql ="insert into board1 (title,text,datetime,id,hit) values ('"+title+"', '"+text+"', now(), '"+id+"', 0)";
		
		try {
			Db.st.executeUpdate(sql);
			System.out.println("글이 작성되었습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
