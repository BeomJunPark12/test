package com.beom.mysql.board;

import java.sql.SQLException;

import com.beom.mysql.display.Display;
import com.beom.mysql.util.Ci;
import com.beom.mysql.util.Db;



public class BoardRead {

	public static void run() {
		String readNo = Ci.r("읽을 글번호를 입력해주세요.");
		try {
			Db.result = Db.st.executeQuery("select * from board1 where num=" + readNo);
			Db.result.next();
			String title = Db.result.getString("title");
			String text = Db.result.getString("text");
			System.out.println("제목: " + title);
			System.out.println("내용: " + text);
			Display.bar();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

}
