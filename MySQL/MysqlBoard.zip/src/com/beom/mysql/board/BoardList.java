package com.beom.mysql.board;

import java.sql.SQLException;

import com.beom.mysql.display.Display;
import com.beom.mysql.util.Db;



public class BoardList {
	static String cmd;
	public static final int PER_PAGE = 3;
	static int startIndex = 0;
	static int totalPage = 0;
	static int currentPage = 1;
	static int count = 0;
	

	public static void run() {
		count = Db.getPostCount();
		
//		if (count % PER_PAGE > 0) {
//			totalPage = count / PER_PAGE + 1;
//			
//		} else {
//			totalPage = count / PER_PAGE;
//		}
//		System.out.println("총 페이지 수: " + totalPage);
//		
//		while(true) {
//			cmd = Ci.rl("이전 메뉴: x, 페이지번호를 입력해주세요");
//			
//			if(cmd.equals("x")) {
//				break;
//			}
//			currentPage = Integer.parseInt(cmd);
//			
//			if(currentPage > totalPage || currentPage < 1) {
//				System.out.println("페이지 범위에 맞는 값을 넣어주세요.");
//				continue;
//			}
//			startIndex = (currentPage - 1) * PER_PAGE;
			
			String sql = "select * from board1 where reply_ori is null"; //limit " + startIndex + "," + PER_PAGE;
			
			try {
				Db.result = Db.st.executeQuery(sql);
				System.out.println("전송한 sql: " + sql);
				Display.bar();
				while(Db.result.next()) {
					String num = Db.result.getString("num");
					String title = Db.result.getString("title");
					String id = Db.result.getString("id");
					String dateTime = Db.result.getString("datetime");
					System.out.println("글번호: "+num+" 제목: "+title+" id: "+id+" 글내용: "+dateTime);
					Display.bar();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
}
		
	


