package com.beom.mysql.board;

import com.beom.mysql.display.Display;
import com.beom.mysql.util.Ci;
import com.beom.mysql.util.Db;

public class Board {
	void run() {
		Db.dbInit();
		loop: while (true) {
			Display.mainMenu();
			String cmd = Ci.rl("명령 입력");
			switch(cmd) {
			case "1":
				BoardList.run();
				break;
			case "2":
				BoardRead.run();
				break;
			case "3":
				BoardWrite.run();
				break;
			case "4":
				BoardDelete.run();
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
				
			}
		}
	}
}
