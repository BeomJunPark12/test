package com.beom.mysql.board;

import com.beom.mysql.util.Ci;
import com.beom.mysql.util.Db;

public class BoardDelete {

	public static void run() {
		
		String delNo = Ci.rl("삭제할 글번호를 입력해주세요.");
		Db.dbExecuteUpdate("delete from board1 where num="+delNo);
		
	}

}
